# Product CRUD API

Spring Boot 3 + Java 17 + PostgreSQL + JPA + Validation + OpenAPI + Docker.

## Run
```bash
docker compose up --build
```

Swagger UI: `http://localhost:8080/swagger-ui.html`

## API
- GET `/api/v1/products?page=0&size=20`
- GET `/api/v1/products/{id}`
- POST `/api/v1/products`
- PUT `/api/v1/products/{id}`
- DELETE `/api/v1/products/{id}`
- GET `/api/v1/products/{id}/items`

Example request:
```json
{"productName":"Laptop"}
```

## Notes
The project includes the requested JWT dependencies and a stateless security baseline. For production, wire the JWT filter, login endpoint, refresh-token rotation store, role model, HTTPS redirect/termination, and CORS allow-list. The sample keeps authentication deliberately small so it is easy to extend.
