package com.example.productapi.product;
import org.junit.jupiter.api.Test;
import org.mockito.Mockito;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.*;
class ProductServiceTest {
  @Test void getThrowsWhenMissing(){
    ProductRepository repo=Mockito.mock(ProductRepository.class);
    Mockito.when(repo.findById(99L)).thenReturn(java.util.Optional.empty());
    assertThrows(RuntimeException.class,()->new ProductService(repo).get(99L));
  }
}
