CREATE INDEX IF NOT EXISTS idx_product_created_on ON product(created_on);
CREATE INDEX IF NOT EXISTS idx_item_product_id ON item(product_id);
