package com.example.productapi.product;
import jakarta.validation.constraints.NotBlank;
public record ProductRequest(@NotBlank(message="productName is required") String productName) {}
