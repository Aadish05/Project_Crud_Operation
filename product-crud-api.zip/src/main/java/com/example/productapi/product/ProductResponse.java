package com.example.productapi.product;
import java.time.Instant;
public record ProductResponse(Long id,String productName,String createdBy,Instant createdOn,String modifiedBy,Instant modifiedOn) {
  static ProductResponse from(Product p){return new ProductResponse(p.getId(),p.getProductName(),p.getCreatedBy(),p.getCreatedOn(),p.getModifiedBy(),p.getModifiedOn());}
}
