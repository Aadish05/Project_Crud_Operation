package com.example.productapi.product;
import jakarta.validation.Valid;
import org.springframework.data.domain.Page;
import org.springframework.http.*;
import org.springframework.security.core.Authentication;
import org.springframework.web.bind.annotation.*;
@RestController @RequestMapping("/api/v1/products")
public class ProductController {
  private final ProductService service;
  public ProductController(ProductService service){this.service=service;}
  @GetMapping public Page<ProductResponse> list(@RequestParam(defaultValue="0") int page,@RequestParam(defaultValue="20") int size){return service.list(page,Math.min(size,100));}
  @GetMapping("/{id}") public ProductResponse get(@PathVariable Long id){return ProductResponse.from(service.get(id));}
  @PostMapping public ResponseEntity<ProductResponse> create(@Valid @RequestBody ProductRequest r,Authentication a){return ResponseEntity.status(HttpStatus.CREATED).body(service.create(r,a.getName()));}
  @PutMapping("/{id}") public ProductResponse update(@PathVariable Long id,@Valid @RequestBody ProductRequest r,Authentication a){return service.update(id,r,a.getName());}
  @DeleteMapping("/{id}") @ResponseStatus(HttpStatus.NO_CONTENT) public void delete(@PathVariable Long id){service.delete(id);}
  @GetMapping("/{id}/items") public Object items(@PathVariable Long id){return service.get(id).getItems();}
}
