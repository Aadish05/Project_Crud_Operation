package com.example.productapi.product;
import org.springframework.data.domain.*;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import java.time.Instant;
@Service
public class ProductService {
  private final ProductRepository repo;
  public ProductService(ProductRepository repo){this.repo=repo;}
  @Transactional(readOnly=true) public Page<ProductResponse> list(int page,int size){
    return repo.findAll(PageRequest.of(page,size,Sort.by("id").descending())).map(ProductResponse::from);
  }
  @Transactional(readOnly=true) public Product get(Long id){return repo.findById(id).orElseThrow(()->new ProductNotFoundException(id));}
  @Transactional public ProductResponse create(ProductRequest r,String user){
    Product p=new Product(); p.setProductName(r.productName()); p.setCreatedBy(user); p.getItems(); 
    try { var f=Product.class.getDeclaredField("createdOn"); f.setAccessible(true); f.set(p,Instant.now()); } catch(Exception e){throw new IllegalStateException(e);}
    return ProductResponse.from(repo.save(p));
  }
  @Transactional public ProductResponse update(Long id,ProductRequest r,String user){
    Product p=get(id); p.setProductName(r.productName()); p.setModifiedBy(user);
    try { var f=Product.class.getDeclaredField("modifiedOn"); f.setAccessible(true); f.set(p,Instant.now()); } catch(Exception e){throw new IllegalStateException(e);}
    return ProductResponse.from(p);
  }
  @Transactional public void delete(Long id){repo.delete(get(id));}
}
class ProductNotFoundException extends RuntimeException { ProductNotFoundException(Long id){super("Product not found: "+id);} }
