package com.example.productapi.config;
import com.example.productapi.product.ProductNotFoundException;
import org.springframework.http.*;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.*;
import java.time.Instant;
import java.util.Map;
@RestControllerAdvice
public class GlobalExceptionHandler {
  @ExceptionHandler(ProductNotFoundException.class) ResponseEntity<?> notFound(Exception e){return ResponseEntity.status(404).body(Map.of("timestamp",Instant.now(),"status",404,"error","NOT_FOUND","message",e.getMessage()));}
  @ExceptionHandler(MethodArgumentNotValidException.class) ResponseEntity<?> validation(MethodArgumentNotValidException e){return ResponseEntity.badRequest().body(Map.of("timestamp",Instant.now(),"status",400,"error","VALIDATION_ERROR","message",e.getBindingResult().getFieldError().getDefaultMessage()));}
}
